#
# def s_calc():
#
#     try:
#         r_val = float(input("Укажите радиус: "))
#         h_val = float(input("Укажите высоту: "))
#     except ValueError:
#         return
#     s_side = 2 * 3.14 * r_val * h_val
#     s_circle = 3.14 * r_val ** 2
#     s_full = s_side + 2 * s_circle
#     return s_full
#
# print(s_calc())

my_list = [1, 'зара', 'джам']

print(my_list[2][0].title())
