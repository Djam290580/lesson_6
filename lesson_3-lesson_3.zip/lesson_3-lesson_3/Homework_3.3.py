# Реализовать функцию my_func(), которая принимает три позиционных аргумента,
# и возвращает сумму наибольших двух аргументов.

def my_func(a_1, a_2, a_3):
    result = ((a_1 + a_2), (a_2 + a_3), (a_1 + a_3))
    return max(result)

print(my_func(30, 10, 1))

#----------------------------------

# def my_func(arg1 , arg2, arg3):
#     if arg1 >= arg3 and arg2 >= arg3:
#         return arg1 + arg2
#     elif arg1 > arg2 and arg1 < arg3:
#         return arg1 + arg3
#     else:
#         return arg2 + arg3
# print(f'Result - {my_func(int(input("enter first argument ")), int(input("enter second argument ")), int(input("enter third argument ")))}')


