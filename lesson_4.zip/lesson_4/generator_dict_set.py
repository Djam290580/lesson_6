# my_dict = {el: el * 2 for el in range(10, 20)}
# print(my_dict)
#
# #  генератор множества set---------------------------
# my_set = {el ** 3 for el in range(2, 11)}
# print(my_set)

# -----------------------------------------------

