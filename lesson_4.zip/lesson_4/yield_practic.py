# yield  --- Это ключевое слово, которое используется как return, за исключением того, что функция вернет генератор

# generator = (i * i for i in range(10))
# my_list = [i * i for i in range(10)]
# # print(len(my_list))
# # print(len(generator))
# for i in generator:
#     print(i)
#
# print(next(generator))

def generator():
    for el in (10, 20, 30):
        yield el

print(generator())
for i in generator():
    print(i)