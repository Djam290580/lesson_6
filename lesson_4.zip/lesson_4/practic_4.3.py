import Lesson_Now as LN # Вызываем функции из Lesson_Now и присваиваем имя LN

LN.sh_w()
print(LN.s_n())

