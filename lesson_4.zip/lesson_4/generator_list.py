# my_list = [1, 2 , 4, 5, 6]
# new_list = [el * 10 for el in my_list]
# print(new_list)

# длинный способ--------------------------------------------

# my_list = [1, 2 , 4, 5, 6]
# new_list = []
# for el in my_list:
#     new_list.append(el * 10)
# print(new_list)
# ----------------------------------------------------------

# my_list = [1, 2, 4, 5, 6]
# new_list = [el for el in my_list if el % 2 == 0]
# print(new_list)

# ----------------------------------------------------------
# str_1 = 'abc'
# str_2 = 'd'
# str_3 = 'efg'
#
# s = [i + j + k for i in str_1 for j in str_2 for k in str_3]
# print(s)
# --------------------------------------------------------

str_1 = 'abc'
str_2 = 'd'
str_3 = 'efg'
sets = []
sets = [i + j + k for i in str_1 for j in str_2 for k in str_3]
# for i in str_1:
#     for j in str_2:
#         for k in str_3:
#             sets.append(i + j + k)

print(sets)