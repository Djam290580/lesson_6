import math as m # Присваиваем псевдоним 'm'
import os
import sys


print(m.pi)
