# Реализовать скрипт, в котором должна быть предусмотрена функция расчета заработной платы сотрудника.
# В расчете необходимо использовать формулу: (выработка в часах * ставка в час) + премия.
# Для выполнения расчета для конкретных значений необходимо запускать скрипт с параметрами.

from sys import argv

# sys.argv - список аргументов командной строки, передаваемых сценарию Python.
# sys.argv[0] является именем скрипта (пустой строкой в интерактивной оболочке)

def salaries():
    try:
        salary, output_in_hours, rate, prize = argv
        output_in_hours = int(output_in_hours)
        rate = int(rate)
        prize = int(prize)
        print('Имя скрипта: ', salary)
        print('Выработка в часах: ', output_in_hours)
        print('Ставка в час: ', rate)
        print('Премия: ', prize)
        print(f'Salaries = {output_in_hours * rate + prize}')
    except ValueError:
        print('You need to enter three numbers')

salaries()
