# Реализовать два небольших скрипта:
# а) итератор, генерирующий целые числа, начиная с указанного,
# б) итератор, повторяющий элементы некоторого списка, определенного заранее.
# Подсказка: использовать функцию count() и cycle() модуля itertools.
# Обратите внимание, что создаваемый цикл не должен быть бесконечным. Необходимо предусмотреть условие его завершения.
from itertools import count, cycle, islice
#
for el in count(int(input('Введите число для старта или "Q" для выхода: '))):
    print(el)
    exit = input()
    if exit == 'Q':
        break


for el in cycle(input('Введите элементы списка через пробел или "Q" для выхода - ').split()):
    print(el)
    exit = input()
    if exit == 'Q':
        break

#---------------------------------------------------------------------------------------------------------
# def unexpected(star_el, stop_el, num_str):
#     try:
#         star_el, stop_el, num_str = int(star_el), int(stop_el), int(num_str)
#         my_list = [el for el in islice(count(star_el - 1), 1, stop_el)]
#         # repeat_list = [next(cucle(my_list)) for el in range(num_str)]
#         r_list = iter(el for el in cycle(my_list))
#         repeat_list = [next(r_list) for _ in range(num_str)]
#         print(my_list)
#     except ValueError:
#         return ValueError
#     except TypeError:
#         return TypeError
#
# print(unexpected(input('List starting at - '), input('from to - '), input('Number of repetition - ')))